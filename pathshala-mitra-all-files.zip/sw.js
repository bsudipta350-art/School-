// Service worker for the Coaching Management Portal.
// Caches the app shell so the dashboard still opens when offline.
// Bump CACHE_NAME whenever the shell files change, so old caches get replaced.
const CACHE_NAME = 'coaching-portal-v1';
const APP_SHELL = [
  '/',
  '/uniform-scms-dashboard.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    ).then(() => self.clients.claim())
  );
});

// Cache-first for the app shell, network-first (with cache fallback) for everything else.
// This never caches API/data calls — there are none in this static build, but the
// pattern is here so it stays correct if a real backend is added later.
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const isShellFile = APP_SHELL.some((path) => event.request.url.endsWith(path));

  if (isShellFile) {
    event.respondWith(
      caches.match(event.request).then((cached) => cached || fetch(event.request))
    );
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
